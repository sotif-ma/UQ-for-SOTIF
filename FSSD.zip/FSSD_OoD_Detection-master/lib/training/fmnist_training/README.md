# Training FMNIST model for OoD detection
Modified from the Pytorch official example code of training MNIST: https://github.com/pytorch/examples/tree/master/mnist


```bash
python main.py
# CUDA_VISIBLE_DEVICES=2 python main.py  # to specify GPU id to ex. 2
```