# --------------------------------------------------------
# Grid R-CNN
# Copyright (c) 2015 Intel Labs China
# Licensed under The MIT License [see LICENSE for details]
# Written by Tao Kong
# --------------------------------------------------------