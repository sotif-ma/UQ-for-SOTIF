# Distributed training 
PyTorch-SSO supports data parallelism and MC samples parallelism (for VI) for distributed training among multiple processes (GPUs).

![](../docs/distributed_vi.png)

