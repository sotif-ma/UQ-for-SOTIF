python ../../tools/extra/plot_training_log.py ./plot.png ./*.log

